package com.camada15.clase6;

public class Main {
    public static void main(String[] args) {

        Impresora impresora1 = new Impresora("Epson E34", "USB", "27/10/2022", 10);

        System.out.println(impresora1.tienePapel());
        //impresora1.imprimir("Hola camada 15");
        impresora1.setEstaEncendida(true);
        impresora1.setTieneTinta(true);
        impresora1.setHojasDisponibles(0);
        impresora1.imprimir("Hola camada 15");

        //impresora1.imprimir("Hola camada 15");

    }
}

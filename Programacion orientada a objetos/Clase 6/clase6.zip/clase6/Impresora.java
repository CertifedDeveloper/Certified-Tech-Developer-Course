package com.camada15.clase6;

public class Impresora {
    private String modelo;
    private String tipoConexion;
    private String fechaFabricacion;
    private int hojasDisponibles;
    private boolean tieneTinta;
    private boolean estaEncendida;

    public Impresora(String modelo, String tipoConexion, String fechaFabricacion, int hojasDisponibles) {
        this.modelo = modelo;
        this.tipoConexion = tipoConexion;
        this.fechaFabricacion = fechaFabricacion;
        this.hojasDisponibles = hojasDisponibles;
        tieneTinta = false;
        estaEncendida = false;
    }

    public Impresora(String modelo, String tipoConexion, String fechaFabricacion, int hojasDisponibles, boolean tieneTinta, boolean estaEncendida) {
        this.modelo = modelo;
        this.tipoConexion = tipoConexion;
        this.fechaFabricacion = fechaFabricacion;
        this.hojasDisponibles = hojasDisponibles;
        this.tieneTinta = tieneTinta;
        this.estaEncendida = estaEncendida;
    }

    //Getters y Setters
    public void setEstaEncendida(boolean estaEncendida) {
        this.estaEncendida = estaEncendida;
    }

    public void setTieneTinta(boolean tieneTinta) {
        this.tieneTinta = tieneTinta;
    }

    public void setHojasDisponibles(int hojasDisponibles) {
        this.hojasDisponibles = hojasDisponibles;
    }

    //Metodos propios
    public boolean tienePapel(){
        return hojasDisponibles>0;
    }

    public void imprimir(String texto){
        if(estaEncendida){
            if (tienePapel()) {
                if (tieneTinta) {
                    System.out.println(texto);
                } else {
                    System.out.println("La tinta es insuficiente");
                }
            }
            else {
                System.out.println("La impresora no tiene papel");
            }
        } else {
            System.out.println("La impresora esta apagada. Enciendala");
        }
    }

    public void imprimirDos(String texto){
        if(estaEncendida){
            if(tieneTinta&&tienePapel()){
                System.out.println(texto);
            }
            else {
                System.out.println("No se puede imprimir");
                System.out.println("** Estado de la impresora **" + "\nTinta: " + tieneTinta + "\nPapel: " + hojasDisponibles);
            }
        }
        else {
            System.out.println("La impresora esta apagada");
        }
    }

}

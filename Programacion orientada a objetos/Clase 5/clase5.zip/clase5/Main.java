package com.camada15.clase5;

public class Main {
    public static void main(String[] args) {

        //crear un objeto de tipo Cliente = instanciar un cliente
        Cliente cliente1 = new Cliente(1, "Juan Perez");
        //System.out.println(cliente1.getDeuda());
        //cliente1.setDeuda(0.);
        cliente1.incrementarDeuda(100.);
        cliente1.pagarDeudaParcial(50.);
        cliente1.pagarDeuda();
        System.out.println("Su deuda ha sido saldada. Deuda $" + cliente1.getDeuda());
    }
}

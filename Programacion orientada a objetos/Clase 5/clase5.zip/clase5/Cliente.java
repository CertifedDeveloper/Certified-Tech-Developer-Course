package com.camada15.clase5;

public class Cliente {
    //Atributos
    private Integer numeroCliente;
    private String nombre;
    private Double deuda;


    //Contructor
    public Cliente(Integer numeroCliente, String nombre){
        this.numeroCliente = numeroCliente;
        this.nombre = nombre;
        deuda = 0.;
    }
    //shortcut alt+insert

    //Getter y Setters
    public Integer getNumeroCliente(){
        return numeroCliente;
    }

    public void setNumeroCliente(Integer numeroCliente){
        this.numeroCliente = numeroCliente;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Double getDeuda() {
        return deuda;
    }

    public void setDeuda(Double deuda) {
        this.deuda = deuda;
    }

    //Metodos propios
    public void incrementarDeuda(Double valor){
        deuda+=valor;
        System.out.println("Su deuda actualizada es: $" + deuda);
    }

    public void pagarDeuda(){
        deuda = 0.;
    }

    public void pagarDeudaParcial(Double valorParcial){
        deuda -= valorParcial;
        System.out.println("Su deuda actualizada es de: $" + deuda);
    }
}

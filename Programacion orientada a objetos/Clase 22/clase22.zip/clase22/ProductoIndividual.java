package com.camada15.clase22;

public class ProductoIndividual extends Producto{

    public ProductoIndividual(String nombre, double precio) {
        super(nombre, precio);
    }

}

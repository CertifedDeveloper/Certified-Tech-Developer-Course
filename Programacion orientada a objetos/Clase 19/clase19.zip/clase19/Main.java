package com.camada15.clase19;

public class Main {
    public static void main(String[] args) {

        Empleado empleado1 = EmpleadoFactory.getInstance().construirEmpleado("EMP_RD");
        Empleado empleado2 = EmpleadoFactory.getInstance().construirEmpleado("EMP_PH");

        empleado1.setNombre("Lu");
        System.out.println(empleado1.calcularSueldo(8));

    }
}

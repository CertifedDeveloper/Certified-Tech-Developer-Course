package excepciones;

public class PeliculaNoHabilitadaException  extends Exception{
    public PeliculaNoHabilitadaException(String message) {
        super(message);
    }
}

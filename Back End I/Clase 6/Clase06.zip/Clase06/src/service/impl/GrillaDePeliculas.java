package service.impl;

import model.Pelicula;
import service.IGrillaDePeliculas;

public class GrillaDePeliculas implements IGrillaDePeliculas {
    @Override
    public Pelicula getPelicula(String nombre) {
        return null;
    }
}

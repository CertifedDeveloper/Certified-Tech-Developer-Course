package com.example.ejemplointegrador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemploIntegradorApplicationTests {

	@Test
	void contextLoads() {
	}

}

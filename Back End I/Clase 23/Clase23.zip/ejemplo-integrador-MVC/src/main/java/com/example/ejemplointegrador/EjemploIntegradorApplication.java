package com.example.ejemplointegrador;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjemploIntegradorApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjemploIntegradorApplication.class, args);
	}

}

function cerrar_update_turno(){
    const turno_table = document.getElementById("modify_turno_table")
    turno_table.style.display = "none"
}
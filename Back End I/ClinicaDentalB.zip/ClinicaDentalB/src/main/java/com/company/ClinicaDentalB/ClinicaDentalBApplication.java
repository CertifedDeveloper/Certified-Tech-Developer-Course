package com.company.ClinicaDentalB;

import org.apache.log4j.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.File;


@SpringBootApplication
public class ClinicaDentalBApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClinicaDentalBApplication.class, args);
	}

}

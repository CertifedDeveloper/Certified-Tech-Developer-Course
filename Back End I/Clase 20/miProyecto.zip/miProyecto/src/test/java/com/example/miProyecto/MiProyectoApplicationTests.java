package com.example.miProyecto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiProyectoApplicationTests {

	@Test
	void contextLoads() {
	}

}

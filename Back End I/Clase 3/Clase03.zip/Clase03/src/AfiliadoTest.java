import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AfiliadoTest {

    @Test
    void doTest(){
        assertEquals(1,1);
    }


}
package com.company.ClinicaOdontologicaB.model;

public enum AppUserRole {
    USER,ADMIN
}

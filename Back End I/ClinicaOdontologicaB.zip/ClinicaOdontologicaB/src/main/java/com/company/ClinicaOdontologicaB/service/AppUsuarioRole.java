package com.company.ClinicaOdontologicaB.service;

public enum AppUsuarioRole {
    USER,ADMIN
}
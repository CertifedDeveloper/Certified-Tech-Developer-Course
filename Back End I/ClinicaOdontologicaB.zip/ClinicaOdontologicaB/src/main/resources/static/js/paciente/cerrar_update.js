function cerrar_update_paciente(){
    const paciente_table = document.getElementById("modify_paciente_table")
    paciente_table.style.display = "none"
}
package com.dh.Clase22.Service;

import com.dh.Clase22.model.Entrenador;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
public class EntrenadorServiceImpl implements EntrenadorService{
    @Override
    public List<Entrenador> listaEntrenador() {
        return Arrays.asList(new Entrenador("Pibe"), new Entrenador("Roman"));
    }
}

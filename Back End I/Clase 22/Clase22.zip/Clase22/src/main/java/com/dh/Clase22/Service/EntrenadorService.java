package com.dh.Clase22.Service;

import com.dh.Clase22.model.Entrenador;

import java.util.List;

public interface EntrenadorService {

    List<Entrenador> listaEntrenador();
}

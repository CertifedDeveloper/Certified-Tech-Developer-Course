package com.example.odontologo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OdontologoApplicationTests {

	@Test
	void contextLoads() {
	}

}

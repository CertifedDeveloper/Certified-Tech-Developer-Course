package com.company.ClinicaOdontologicaB.model;

public enum AppUserRole {
    ROLE_USER,ROLE_ADMIN
}

function cerrar_update_odontologo(){
    const odontologo_table = document.getElementById("modify_odontologo_table")
    odontologo_table.style.display = "none"
}